motto = ("Use a 'rand' command to print a random number!",
"Need help? Use a 'help' command!",
"Did you know you can add your program to autostart? Just make an autostart.py file!",
"With a 'run' command you can run you own programs!")