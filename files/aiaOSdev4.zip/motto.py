motto = ("Use a 'rand' command to print a random number!",
"Need help? Use a 'help' command!",
"Did you know you can add your program to autostart? Just link your file into the config!",
"With a 'run' command you can run you own programs!",
"Documentation is available on aiaOS's official site!",
"There are some interesting options in config.json...")